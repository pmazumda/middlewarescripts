const app = require('http');
const port = process.env.port || 15000 

const server = app.createServer((req, res) => {
    res.end(`Hi TCGUSER this is response from bl4ul020 ohs on port ${port}.`);
});

server.listen(port);
